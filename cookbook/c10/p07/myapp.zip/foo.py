def func2():
    print("foo func2....")