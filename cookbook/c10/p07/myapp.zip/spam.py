def func1():
    print("spam func1....")