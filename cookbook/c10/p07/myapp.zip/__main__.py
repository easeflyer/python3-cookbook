import foo
import spam

foo.func2()
spam.func1()


'''
官方方案：
目录结构和 zip 一致，也是要写好 __main__.py

$ python -m zipapp myapp    # 把 myapp 目录打包成 .pyz
$ python myapp.pyz          # 直接运行即可。
<output from myapp>    

$ python -m zipapp myapp -p "/usr/bin/env python"
# 这样打包后。可以直接运行，不用加 python
$ ./myaqpp.pyz 

'''